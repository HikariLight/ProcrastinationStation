# Procrastination Station to-do list app

## Group members
- MERZOUGUI Dhia Eddine G3A (21812920)
- MERCIER Juliee G3A
- HEIDARI Schahin 

## How to run
```
npm run serve
```
