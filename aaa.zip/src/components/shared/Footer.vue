<template>
  <footer id="footer">
      <div class="footer-top">
        <div class="container">
          <div class="row">
            <div class="col-sm-3">
              <div class="address">
                <img src="../images/map.png" alt>
              </div>
            </div>
            
            <div class="col-sm-6">
              <div class="companyinfo">
                <h2>
                  <span>Web</span>Application
                </h2>
                <h4> About Us :</h4>
                <p>
                  Nous avons travaillees en utilisant Git (hébergé sur Github ou Gitlab) from day 1, 
                  la bonne utilisation et collaboration fera partie de la note (utilisation des branches, 
                  dommage des commits …). Notre repo doit être public et nous avons l’indiquees dès le début du projet.
                  nous nous avons inscrit notre groupe sur le fichier suivant : 
                  https://docs.google.com/spreadsheets/d/1ZexML92Q0_jbHFP6jWFwHwCsa4yldtZN-lJ2NXjuydo/edit?usp=sharing 
                  on écrit « à la fin de la liste » ). 
                  Dans Notre case étudiant indiqué nos nom prénom et identifiant d'étudiant.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="footer-bottom" style="direction: ltr !important;">
        <div class="container">
          <div class="row">
            <p class="pull-left">
              MERZOUGUI Dhia Eddine G3A, MERCIER Juliee G3A, HEIDARI Shahin G1B, DIALLO Mamadou Galle, KASENGA K. Deborah
            </p>
          </div>
        </div>
      </div>
    </footer>
</template>

<script>
export default {

}
</script>
