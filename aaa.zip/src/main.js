import { createApp } from 'vue'
import App from './App.vue'
import { Routes } from './Routes'
import VueRouter from 'vue-router'


createApp(App).mount('#app');
Routes(VueRouter).mount('#app');

export const main = [{
    path: '/',
    component: Routes,
}];

